import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appResaltado]'
})
export class ResaltadoDirective {

  /**
   * @param item Se refiere al elemento HTML al que fue aplicada la directiva
   */
  constructor( private item: ElementRef ) {
    console.log('Called');
  }

  // --------- DATOS DE ENTRADA
  @Input('appResaltado') color: string;

  // --------- EVENTOS
  @HostListener('mouseenter') mouseEnter() {
    if ( !this.color ) {
      this.color = 'yellow';
    }

    this.resaltar( this.color );
  }

  @HostListener('mouseleave') mouseLeave() {
    this.resaltar( null );
  }

  private resaltar( value ) {
    const element = this.item.nativeElement;
    // font color
    if ( value == null ) {
      element.style.color = '#000';
    } else {
      element.style.color = '#fff';
    }
    // background
    element.style.backgroundColor = value;
  }

}
