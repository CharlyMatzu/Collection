import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usuario-editar',
  template: `
    <p>
      usuario-editar works!
    </p>
  `,
  styles: []
})
export class UsuarioEditarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
