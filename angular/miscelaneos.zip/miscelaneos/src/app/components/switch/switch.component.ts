import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch',
  templateUrl: './switch.component.html',
  styles: []
})
export class SwitchComponent implements OnInit {

  private colors: any = ['primary', 'warning', 'success', 'NA'];
  alerta = 'primary';

  constructor() { }

  ngOnInit() {
  }

  cambiarAlerta() {
    const index = Math.floor(Math.random() * 4);
    this.alerta = this.colors[index];

    console.log( this.alerta );
  }

}
