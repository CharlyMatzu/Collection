import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-async',
  templateUrl: './async.component.html',
  styles: []
})
export class AsyncComponent {

  loading = false;

  constructor() { }

  run() {
    this.loading = true;
    setTimeout( () => this.loading = false, 3000 );
  }

}
