import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css',
  template: `
    <h3>CSS</h3><hr>

    <p>
      css works!
    </p>
  `,
  // Estilo que afecta solo al scope del componente adicionando un atributo al mismo
  styles: [`
    p{
      color: red;
      font-size: 20px;
    }
  `]
})
export class CssComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
