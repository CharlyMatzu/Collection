import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-style',
  template: `
    <h3>STYLE</h3><hr>

    <button class="btn btn-primary" (click)="size = size + 4"><i class="fa fa-plus"></i></button>
    <button class="btn btn-primary" (click)="size = size - 4"><i class="fa fa-minus"></i></button>

    <button class="btn btn-danger" (click)="color = 'red'">RED</button>
    <button class="btn btn-success" (click)="color = 'green'">GREEN</button>

    <p [style.fontSize.px]="size">
      ng-style works!
    </p>
    <p [ngStyle]="{ 'font-size': size + 'px', 'color': color }">
      ng-style works!
    </p>

  `,
  styles: []
})
export class NgStyleComponent implements OnInit {

  size = 30;
  color = 'red';

  constructor() { }

  ngOnInit() {
  }

}
